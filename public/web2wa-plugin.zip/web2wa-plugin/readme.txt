=== Web2WA - WhatsApp Order & Logistics Bridge ===
Contributors: aistudio
Tags: woocommerce, whatsapp, logistics, checkout, orders
Requires at least: 5.4
Tested up to: 6.5
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connects WooCommerce orders with WhatsApp for customer communication and delivery logistics.

== Description ==
Web2WA bridges WooCommerce checkout with WhatsApp. Customers pay via standard payment gateways (Stripe, PayPal, Cash on Delivery, etc.) and are provided a direct WhatsApp button on the Thank You page pre-populated with their order details to arrange logistics and delivery.

== Installation ==
1. Go to Plugins > Add New > Upload Plugin.
2. Select web2wa-plugin.zip and click Install Now.
3. Activate the plugin.
4. Navigate to Settings > WhatsApp Logistics in WordPress admin to set your WhatsApp phone number.
